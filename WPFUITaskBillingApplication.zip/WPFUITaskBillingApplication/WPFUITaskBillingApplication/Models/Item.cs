﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFUITaskBillingApplication.Models
{
    public class Item
    {
        public string Name { get; set; }
        public decimal OrgPrice { get; set; }
        public decimal EfctPrice { get; set; }
        public string Image { get; set; }
        public bool Tax { get; set; }
        public decimal Discount { get; set; }
        public string Category { get; set; }


    }

    public class SelectedItem : Item
    {
        public int Quantity { get; set; } = 1;
        public bool DeleteButtonVisible => Quantity <= 1;
        public decimal Total => EfctPrice * Quantity;
    }

}
