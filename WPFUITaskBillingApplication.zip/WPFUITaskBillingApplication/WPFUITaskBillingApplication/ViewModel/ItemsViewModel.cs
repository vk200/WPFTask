﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using WPFUITaskBillingApplication.Commands;
using WPFUITaskBillingApplication.Extensionsmethods;
using WPFUITaskBillingApplication.Models;

namespace WPFUITaskBillingApplication.ViewModel
{
    public class ItemsViewModel : INotifyPropertyChanged
    {
        #region Properties
        private int _taxRate => 5; //Default tax rate (%) for all applicable items.

        private ObservableCollection<Item> _items;
        public ObservableCollection<Item> Items
        {
            get => _items;
            set 
            { 
                _items = value;
                OnPropertyChanged(nameof(Items));
            }
        }
        private ObservableCollection<SelectedItem> _selectedItems;
        public ObservableCollection<SelectedItem> SelectedItems
        {
            get => _selectedItems;
            set
            {
                _selectedItems = value;
                OnPropertyChanged(nameof(SelectedItems));
            }
        }

        public static ObservableCollection<Item> AllItems => new ObservableCollection<Item>()
        {
            // Food category
            new Item { Name = "Garlic Bread", OrgPrice = 4.00m, EfctPrice = 4.00m, Image = "D:\\WPFTaskVikash\\WPFUITaskBillingApplication\\WPFUITaskBillingApplication\\Images\\Food\\GarlicBread.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Onion", OrgPrice = 4.00m, EfctPrice = 4.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Onion.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Macarons", OrgPrice = 6.00m, EfctPrice = 6.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Macarons.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Quesadilla", OrgPrice = 12.00m, EfctPrice = 12.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Quesadilla.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Soup", OrgPrice = 7.00m, EfctPrice = 7.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Soup.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Sandwich", OrgPrice = 13.00m, EfctPrice = 13.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Sandwich.png", Tax = false, Discount = 0, Category = "Food" },
            new Item { Name = "Bread", OrgPrice = 3.00m, EfctPrice = 3.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Bread.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Burger", OrgPrice = 8.00m, EfctPrice = 8.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Burger.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Cheese", OrgPrice = 5.00m, EfctPrice = 5.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Cheese.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Paratha", OrgPrice = 4.50m, EfctPrice = 4.50m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Paratha.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Pastry", OrgPrice = 7.50m, EfctPrice = 7.50m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Pastry.png", Tax = true, Discount = 0, Category = "Food" },
            new Item { Name = "Wrap", OrgPrice = 9.00m, EfctPrice = 9.00m, Image = "WPFUITaskBillingApplication\\Images\\Food\\Wrap.png", Tax = true, Discount = 0, Category = "Food" },

            // Hygiene category
            new Item { Name = "Dettol Hand Sanitizer", OrgPrice = 25.00m, EfctPrice = 25.00m, Image = "Images\\Hygiene\\Sanitizer.png", Tax = true, Discount = 0, Category = "Hygiene" },
            new Item { Name = "Dettol", OrgPrice = 20.00m, EfctPrice = 20.00m, Image = "WPFUITaskBillingApplication\\Images\\Hygiene\\Dettol.png", Tax = true, Discount = 0, Category = "Hygiene" },
            new Item { Name = "Fragrance", OrgPrice = 15.00m, EfctPrice = 15.00m, Image = "WPFUITaskBillingApplication\\Images\\Hygiene\\Fragrance.png", Tax = true, Discount = 0, Category = "Hygiene" },
            new Item { Name = "Hairdryer", OrgPrice = 50.00m, EfctPrice = 50.00m, Image = "WPFUITaskBillingApplication\\Images\\Hygiene\\Hairdryer.png", Tax = true, Discount = 0, Category = "Hygiene" },
            new Item { Name = "Shampoo", OrgPrice = 10.00m, EfctPrice = 10.00m, Image = "WPFUITaskBillingApplication\\Images\\Hygiene\\Shampoo.png", Tax = true, Discount = 0, Category = "Hygiene" },
            new Item { Name = "Toothbrush", OrgPrice = 3.00m, EfctPrice = 3.00m, Image = "WPFUITaskBillingApplication\\Images\\Hygiene\\Toothbrush.png", Tax = true, Discount = 0, Category = "Hygiene" },
            new Item { Name = "Toothpaste", OrgPrice = 4.00m, EfctPrice = 4.00m, Image = "WPFUITaskBillingApplication\\Images\\Hygiene\\Toothpaste.png", Tax = true, Discount = 0, Category = "Hygiene" },

            // Candy category
            new Item { Name = "Caramel", OrgPrice = 2.00m, EfctPrice = 2.00m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\CaramelCandy.png", Tax = true, Discount = 0, Category = "Candy" },
            new Item { Name = "Caramel Popcorn", OrgPrice = 3.00m, EfctPrice = 3.00m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\CaramelPopcorn.png", Tax = true, Discount = 0, Category = "Candy" },
            new Item { Name = "Chocolate Strawberry", OrgPrice = 2.50m, EfctPrice = 2.50m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\ChocolateStrawberry.png", Tax = true, Discount = 0, Category = "Candy" },
            new Item { Name = "Cotton", OrgPrice = 2.00m, EfctPrice = 2.00m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\CottonCandy.png", Tax = true, Discount = 0, Category = "Candy" },
            new Item { Name = "Gummies", OrgPrice = 2.50m, EfctPrice = 2.50m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\Gummies.png", Tax = true, Discount = 0, Category = "Candy" },
            new Item { Name = "Hard Candy", OrgPrice = 1.50m, EfctPrice = 1.50m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\HardCandy.png", Tax = true, Discount = 0, Category = "Candy" },
            new Item { Name = "Lollipop Candy", OrgPrice = 1.00m, EfctPrice = 1.00m, Image = "WPFUITaskBillingApplication\\Images\\Candy\\Lollypops.png", Tax = true, Discount = 0, Category = "Candy" },

            // Stationery category
            new Item { Name = "Color", OrgPrice = 5.00m, EfctPrice = 5.00m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\Color.png", Tax = false, Discount = 0, Category = "Stationery" },
            new Item { Name = "Geometry Box", OrgPrice = 8.00m, EfctPrice = 8.00m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\GeometryBox.png", Tax = false, Discount = 0, Category = "Stationery" },
            new Item { Name = "Notebook", OrgPrice = 3.50m, EfctPrice = 3.50m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\NoteBook.png", Tax = false, Discount = 0, Category = "Stationery" },
            new Item { Name = "Pen", OrgPrice = 1.00m, EfctPrice = 1.00m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\Pen.png", Tax = false, Discount = 0, Category = "Stationery" },
            new Item { Name = "Pencil", OrgPrice = 0.50m, EfctPrice = 0.50m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\Pencil.png", Tax = false, Discount = 0, Category = "Stationery" },
            new Item { Name = "Stapler", OrgPrice = 6.00m, EfctPrice = 6.00m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\Stapler.png", Tax = false, Discount = 0, Category = "Stationery" },
            new Item { Name = "Sticky Notes", OrgPrice = 2.00m, EfctPrice = 2.00m, Image = "WPFUITaskBillingApplication\\Images\\Stationery\\StickyNotes.png", Tax = false, Discount = 0, Category = "Stationery" },
        };

        private decimal _total;
        public decimal Total
        {
            get { return _total; }
            set { _total = value; OnPropertyChanged(nameof(Total)); }
        }
        private decimal _totalDiscount;
        public decimal TotalDiscount
        {
            get { return _totalDiscount; }
            set { _totalDiscount = value; OnPropertyChanged(nameof(TotalDiscount)); }
        }
        private int _totalItems;
        public int TotalItems
        {
            get { return _totalItems; }
            set { _totalItems = value; OnPropertyChanged(nameof(TotalItems)); }
        }
        private decimal _totalPurchased;
        public decimal TotalPurchased
        {
            get { return _totalPurchased; }
            set { _totalPurchased = value; OnPropertyChanged(nameof(TotalPurchased)); }
        }
        private decimal _totalTax;
        public decimal TotalTax
        {
            get { return _totalTax; }
            set { _totalTax = value; OnPropertyChanged(nameof(TotalTax)); }
        }
        #endregion

        #region Commands
        public ICommand FoodItemsCommand { get; }
        public ICommand StationeryItemsCommand { get; }
        public ICommand CandyItemsCommand { get; }
        public ICommand HygieneItemsCommand { get; }

        public ICommand AddItemCommand { get; set; }
        public ICommand RemoveItemCommand { get; set; }
        public ICommand IncreaseQuantityCommand { get; set; }
        public ICommand DecreaseQuantityCommand { get; set; }
        #endregion

        #region Constructor
        public ItemsViewModel()
        {
            Items = new ObservableCollection<Item>();
            AllItems.ForEach(item => { item.Discount = item.OrgPrice - item.EfctPrice; });
            SelectedItems = new ObservableCollection<SelectedItem>();

            FoodItemsCommand = new DelegateCommand(_ => LoadItemsByCategory("Food"));
            StationeryItemsCommand = new DelegateCommand(_ => LoadItemsByCategory("Stationery"));
            CandyItemsCommand = new DelegateCommand(_ => LoadItemsByCategory("Candy"));
            HygieneItemsCommand = new DelegateCommand(_ => LoadItemsByCategory("Hygiene"));

            AddItemCommand = new RelayCommand<Item>(AddItem);
            RemoveItemCommand = new RelayCommand<SelectedItem>(RemoveItem);
            IncreaseQuantityCommand = new RelayCommand<SelectedItem>(IncreaseQuantity);
            DecreaseQuantityCommand = new RelayCommand<SelectedItem>(DecreaseQuantity);
        }
        #endregion

        #region Methods
        private void LoadItemsByCategory(string category)
        {
            Items.Clear();
            foreach (var item in AllItems.Where(x => x.Category == category))
            {
                Items.Add(item);
            }
            OnPropertyChanged(nameof(Items));
        }

        private void AddItem(Item item)
        {
            var selectedItem = SelectedItems.FirstOrDefault(x => x.Name == item.Name);
            if (selectedItem != null)
            {
                selectedItem.Quantity++;
            }
            else
            {
                SelectedItems.Add(new SelectedItem
                {
                    Name = item.Name,
                    OrgPrice = item.OrgPrice,
                    EfctPrice = item.EfctPrice,
                    Image = item.Image,
                    Tax = item.Tax,
                    Discount = item.Discount,
                    Category = item.Category
                });
            }
            OnPropertyChanged(nameof(SelectedItems));
            CalculateTotal();
        }

        private void RemoveItem(SelectedItem item)
        {
            SelectedItems.Remove(item);
            OnPropertyChanged(nameof(SelectedItems));
            CalculateTotal();
        }

        private void IncreaseQuantity(SelectedItem item)
        {
            item.Quantity += 1;
            OnPropertyChanged(nameof(SelectedItems));
            OnPropertyChanged(nameof(item.Quantity));
            CalculateTotal();
        }

        private void DecreaseQuantity(SelectedItem item)
        {
            if (item.Quantity > 1)
            {
                item.Quantity--;
                OnPropertyChanged(nameof(item));
            }
            else
            {
                RemoveItem(item);
            }
            OnPropertyChanged(nameof(SelectedItems));
            CalculateTotal();
        }

        private void CalculateTotal()
        {
            TotalPurchased = SelectedItems.Sum(item => item.Total);
            TotalTax = TaxCalculation(SelectedItems.Where(item => item.Tax));
            TotalItems = SelectedItems.Sum(item => item.Quantity);
            TotalDiscount = SelectedItems.Sum(item => item.Discount);
            Total = TotalPurchased + TotalTax;
        }

        private decimal TaxCalculation(IEnumerable<SelectedItem> items)
        {
            if (items == null) return 0;
            return items.Sum(item => (item.EfctPrice * _taxRate / 100) * item.Quantity);
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
