﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Markup;

namespace WPFUITaskBillingApplication.Converters
{
    public class CurrencyConverter : MarkupExtension, IValueConverter
    {
        private static CurrencyConverter _instance;

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is Decimal decimalnumber  ? decimalnumber.ToString("C",CultureInfo.CurrentCulture):value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return _instance ?? (_instance = new CurrencyConverter());
        }
    }
}
